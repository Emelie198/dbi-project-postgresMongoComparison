# PMRC - Postgres Mongo Runtime Comparison
A Backend which provides interfaces for PostgreSQL &amp; MongoDB Databases, in order to check the execution time for various operations
